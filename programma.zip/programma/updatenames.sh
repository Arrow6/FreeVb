#!/bin/bash
./runtime/updatenames.py "$@"
